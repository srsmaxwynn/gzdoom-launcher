GZDoom Launcher v1.4
Made by PGgamer

If you find some bugs please report them!
GZDoom is not mine https://zdoom.org/
Doom is not mine, it's made by ID Software© 1989

# CHANGELOG
- v1.4 new features: Added a remove IWAD and PWADs button. Removed the window that asks you to copy the WAD in the IWADs/PWADs folder.
Fixes and minor things:
Now you can see the whole WAD path.
New text that tells you can use CTRL and SHIFT to select multiple PWADs.
Now you can add multiple wads at the same time with the + button.

- v1.3 new features: Now you can also download LZDoom and ZDoom from the launcher.

- v1.2 new features: Added profiles! Now you can export and import settings. Added the info button (?).

- v1.1 new features: Replaced the "Open folder" button with the "Add WAD" one.