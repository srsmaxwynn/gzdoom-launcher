GZDoom Launcher v1.2
Made by PGgamer

If you find some bugs please report them!
GZDoom is not mine https://zdoom.org/
Doom is not mine, it's made by ID Software© 1989

It's Malware-Free, but it isn't digital signed.
If you want to check the source code go on my site.